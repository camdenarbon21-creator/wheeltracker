import { WheelState, defaultState } from './wheel'

const KEY = 'wheeltrack_v1'

export function loadState(): WheelState {
  if (typeof window === 'undefined') return defaultState()
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return defaultState()
    return { ...defaultState(), ...JSON.parse(raw) }
  } catch {
    return defaultState()
  }
}

export function saveState(state: WheelState): void {
  if (typeof window === 'undefined') return
  localStorage.setItem(KEY, JSON.stringify(state))
}

export function resetState(): WheelState {
  if (typeof window !== 'undefined') localStorage.removeItem(KEY)
  return defaultState()
}
