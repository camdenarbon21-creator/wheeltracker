export const HOOD_PRICE_DEFAULT = 106
export const PREMIUM_PER_CONTRACT = 200

export interface Lot {
  id: string
  shares: number
  price: number
  source: 'bought' | 'premium'
  date?: string
  note?: string
}

export interface WheelState {
  lots: Lot[]
  hoodStartPrice: number
  currentHoodPrice: number
  premiumPerContract: number
  weeklyLog: WeeklyEntry[]
  createdAt: string
}

export interface WeeklyEntry {
  id: string
  week: string
  premium: number
  sharesAdded: number
  priceAtTime: number
  note?: string
}

export interface ProjectionPoint {
  month: number
  shares: number
  weeklyPremium: number
  contracts: number
}

export interface Milestone {
  shares: number
  month: number
  week: number
  weeklyPremium: number
  totalPremium: number
}

export function calcProjection(startShares: number, premiumPerContract: number, hoodPrice: number, years = 10): {
  milestones: Milestone[]
  weeklyData: ProjectionPoint[]
  finalShares: number
  finalWeeklyPremium: number
  totalPremium: number
} {
  const weeks = years * 52
  let shares = Math.max(startShares, 1)
  let totalPremium = 0
  const milestones: Milestone[] = []
  const weeklyData: ProjectionPoint[] = []

  const milestoneTargets = new Set<number>()
  for (let m = Math.ceil(shares / 100) * 100; m <= 3000; m += 100) {
    milestoneTargets.add(m)
  }

  for (let w = 1; w <= weeks; w++) {
    const contracts = Math.floor(shares / 100)
    const weeklyPremium = contracts * premiumPerContract
    totalPremium += weeklyPremium
    shares += weeklyPremium / hoodPrice

    for (const target of [...milestoneTargets]) {
      if (shares >= target) {
        milestones.push({
          shares: target,
          week: w,
          month: Math.round(w / 4.33),
          weeklyPremium: Math.floor(target / 100) * premiumPerContract,
          totalPremium: Math.round(totalPremium),
        })
        milestoneTargets.delete(target)
      }
    }

    if (w % 4 === 0) {
      weeklyData.push({
        month: Math.round(w / 4.33),
        shares: Math.round(shares),
        weeklyPremium: Math.floor(shares / 100) * premiumPerContract,
        contracts: Math.floor(shares / 100),
      })
    }
  }

  const final = Math.round(shares)
  return {
    milestones: milestones.slice(0, 25),
    weeklyData,
    finalShares: final,
    finalWeeklyPremium: Math.floor(final / 100) * premiumPerContract,
    totalPremium: Math.round(totalPremium),
  }
}

export function derivedStats(state: WheelState) {
  const { lots, currentHoodPrice, premiumPerContract } = state
  const totalShares = lots.reduce((s, l) => s + l.shares, 0)
  const totalCost = lots.reduce((s, l) => s + l.shares * l.price, 0)
  const avgCost = totalShares > 0 ? totalCost / totalShares : 0

  const boughtLots = lots.filter(l => l.source === 'bought')
  const premiumLots = lots.filter(l => l.source === 'premium')
  const boughtShares = boughtLots.reduce((s, l) => s + l.shares, 0)
  const premiumShares = premiumLots.reduce((s, l) => s + l.shares, 0)
  const boughtCost = boughtLots.reduce((s, l) => s + l.shares * l.price, 0)
  const premiumCost = premiumLots.reduce((s, l) => s + l.shares * l.price, 0)
  const boughtAvg = boughtShares > 0 ? boughtCost / boughtShares : 0
  const premiumAvg = premiumShares > 0 ? premiumCost / premiumShares : 0

  const contracts = Math.floor(totalShares / 100)
  const weeklyPremium = contracts * premiumPerContract
  const marketValue = totalShares * currentHoodPrice
  const unrealizedPL = marketValue - totalCost
  const unrealizedPct = totalCost > 0 ? (unrealizedPL / totalCost) * 100 : 0

  const sharesNeeded = Math.max(0, 200 - totalShares)
  const weeksTo200 = weeklyPremium > 0 ? Math.ceil((sharesNeeded * currentHoodPrice) / weeklyPremium) : null

  return {
    totalShares, totalCost, avgCost,
    boughtShares, premiumShares, boughtCost, premiumCost, boughtAvg, premiumAvg,
    contracts, weeklyPremium, marketValue, unrealizedPL, unrealizedPct,
    sharesNeeded, weeksTo200,
    progressTo200: Math.min((totalShares / 200) * 100, 100),
    annualPremium: weeklyPremium * 52,
    yieldOnCost: totalCost > 0 ? (weeklyPremium * 52 / totalCost) * 100 : 0,
  }
}

export function formatMoney(n: number): string {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`
  if (n >= 1_000) return `$${(n / 1_000).toFixed(1)}K`
  return `$${Math.round(n).toLocaleString()}`
}

export function defaultState(): WheelState {
  return {
    lots: [{ id: '1', shares: 100, price: 106, source: 'bought', date: new Date().toISOString().split('T')[0] }],
    hoodStartPrice: 106,
    currentHoodPrice: 106,
    premiumPerContract: 200,
    weeklyLog: [],
    createdAt: new Date().toISOString(),
  }
}
