'use client'
import { useState } from 'react'
import { WheelState, Lot, derivedStats } from '@/lib/wheel'

interface Props {
  state: WheelState
  onChange: (s: WheelState) => void
}

export default function Positions({ state, onChange }: Props) {
  const [newShares, setNewShares] = useState('')
  const [newPrice, setNewPrice] = useState('')
  const [newSource, setNewSource] = useState<'bought' | 'premium'>('bought')
  const [newDate, setNewDate] = useState(new Date().toISOString().split('T')[0])
  const [newNote, setNewNote] = useState('')
  const s = derivedStats(state)

  const addLot = () => {
    const sh = parseFloat(newShares)
    const pr = parseFloat(newPrice)
    if (!sh || sh <= 0 || !pr || pr <= 0) return
    const lot: Lot = { id: Date.now().toString(), shares: sh, price: pr, source: newSource, date: newDate, note: newNote || undefined }
    onChange({ ...state, lots: [...state.lots, lot] })
    setNewShares(''); setNewPrice(''); setNewNote('')
  }

  const removeLot = (id: string) => onChange({ ...state, lots: state.lots.filter(l => l.id !== id) })

  const updateLot = (id: string, field: keyof Lot, value: string | number) => {
    onChange({ ...state, lots: state.lots.map(l => l.id === id ? { ...l, [field]: value } : l) })
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* Settings */}
      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(0,255,135,0.7)', letterSpacing: 1.2, fontWeight: 700, marginBottom: 14 }}>STRATEGY SETTINGS</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div>
            <label style={{ fontSize: 10, color: 'rgba(255,255,255,0.45)', display: 'block', marginBottom: 6, letterSpacing: 0.8 }}>HOOD CURRENT PRICE ($)</label>
            <input type="number" value={state.currentHoodPrice} onChange={e => onChange({ ...state, currentHoodPrice: parseFloat(e.target.value) || 106 })} placeholder="106" />
          </div>
          <div>
            <label style={{ fontSize: 10, color: 'rgba(255,255,255,0.45)', display: 'block', marginBottom: 6, letterSpacing: 0.8 }}>PREMIUM/CONTRACT/WK ($)</label>
            <input type="number" value={state.premiumPerContract} onChange={e => onChange({ ...state, premiumPerContract: parseFloat(e.target.value) || 200 })} placeholder="200" />
          </div>
        </div>
      </div>

      {/* Add lot */}
      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(0,255,135,0.7)', letterSpacing: 1.2, fontWeight: 700, marginBottom: 14 }}>ADD A SHARE LOT</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
          <div>
            <label style={{ fontSize: 10, color: 'rgba(255,255,255,0.45)', display: 'block', marginBottom: 6, letterSpacing: 0.8 }}>SHARES</label>
            <input type="number" value={newShares} onChange={e => setNewShares(e.target.value)} placeholder="e.g. 100" />
          </div>
          <div>
            <label style={{ fontSize: 10, color: 'rgba(255,255,255,0.45)', display: 'block', marginBottom: 6, letterSpacing: 0.8 }}>PRICE PAID ($)</label>
            <input type="number" value={newPrice} onChange={e => setNewPrice(e.target.value)} placeholder="e.g. 106.50" />
          </div>
          <div>
            <label style={{ fontSize: 10, color: 'rgba(255,255,255,0.45)', display: 'block', marginBottom: 6, letterSpacing: 0.8 }}>DATE</label>
            <input type="date" value={newDate} onChange={e => setNewDate(e.target.value)} />
          </div>
          <div>
            <label style={{ fontSize: 10, color: 'rgba(255,255,255,0.45)', display: 'block', marginBottom: 6, letterSpacing: 0.8 }}>NOTE (optional)</label>
            <input type="text" value={newNote} onChange={e => setNewNote(e.target.value)} placeholder="e.g. week 3 premium" />
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
          {(['bought', 'premium'] as const).map(src => (
            <button key={src} onClick={() => setNewSource(src)} style={{ flex: 1, padding: '10px 0', borderRadius: 10, border: newSource === src ? `1px solid ${src === 'premium' ? 'rgba(0,255,135,0.5)' : 'rgba(255,255,255,0.3)'}` : '1px solid transparent', background: newSource === src ? (src === 'premium' ? 'rgba(0,255,135,0.1)' : 'rgba(255,255,255,0.1)') : 'rgba(255,255,255,0.04)', color: newSource === src ? (src === 'premium' ? '#00ff87' : '#fff') : 'rgba(255,255,255,0.4)', fontWeight: 700, fontSize: 13, cursor: 'pointer' }}>
              {src === 'bought' ? '💵 Purchased' : '🔄 From Premium'}
            </button>
          ))}
        </div>
        <button className="btn-primary" onClick={addLot}>+ Add Lot</button>
      </div>

      {/* Lots list */}
      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, fontWeight: 700, marginBottom: 14 }}>ALL LOTS</div>
        {state.lots.length === 0 && <div style={{ color: 'rgba(255,255,255,0.25)', fontSize: 13 }}>No lots yet.</div>}
        {state.lots.map((lot, i) => (
          <div key={lot.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 0', borderBottom: i < state.lots.length - 1 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}>
            <div style={{ fontSize: 18, flexShrink: 0 }}>{lot.source === 'premium' ? '🔄' : '💵'}</div>
            <div style={{ flex: 1, display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
              <input type="number" value={lot.shares} onChange={e => updateLot(lot.id, 'shares', parseFloat(e.target.value) || 0)} style={{ width: 75, fontSize: 14 }} />
              <span style={{ color: 'rgba(255,255,255,0.35)', fontSize: 12 }}>sh @</span>
              <input type="number" value={lot.price} onChange={e => updateLot(lot.id, 'price', parseFloat(e.target.value) || 0)} style={{ width: 85, fontSize: 14 }} />
              <select value={lot.source} onChange={e => updateLot(lot.id, 'source', e.target.value)} style={{ width: 'auto', fontSize: 12, padding: '8px 10px' }}>
                <option value="bought">Purchased</option>
                <option value="premium">Premium</option>
              </select>
            </div>
            <div style={{ textAlign: 'right', flexShrink: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 700 }}>${(lot.shares * lot.price).toFixed(0)}</div>
              {lot.date && <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)' }}>{lot.date}</div>}
              <button onClick={() => removeLot(lot.id)} style={{ background: 'none', border: 'none', color: '#ff4444', cursor: 'pointer', fontSize: 10, padding: 0 }}>remove</button>
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div style={{ background: 'linear-gradient(135deg, #0a1f14, #091525)', border: '1px solid rgba(0,255,135,0.2)', borderRadius: 18, padding: 20 }}>
        <div style={{ fontSize: 10, color: 'rgba(0,255,135,0.7)', letterSpacing: 1.2, fontWeight: 700, marginBottom: 14 }}>COST BASIS SUMMARY</div>
        {[
          { label: 'Total Shares', value: s.totalShares.toFixed(2) },
          { label: 'Capital Deployed', value: `$${s.totalCost.toFixed(2)}` },
          { label: 'Purchased Avg', value: `$${s.boughtAvg.toFixed(2)}` },
          { label: 'Premium Shares Avg', value: s.premiumShares > 0 ? `$${s.premiumAvg.toFixed(2)}` : '—', color: '#00ff87' },
          { label: '🎯 Blended Avg Cost Basis', value: `$${s.avgCost.toFixed(2)}`, color: '#00ff87', bold: true },
        ].map((row, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '9px 0', borderBottom: i < 4 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}>
            <span style={{ fontSize: row.bold ? 14 : 13, color: row.bold ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.5)', fontWeight: row.bold ? 700 : 400 }}>{row.label}</span>
            <span style={{ fontSize: row.bold ? 17 : 14, fontWeight: 800, color: row.color || '#fff' }}>{row.value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
