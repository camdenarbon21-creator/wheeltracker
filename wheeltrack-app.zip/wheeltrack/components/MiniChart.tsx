'use client'
import { ProjectionPoint } from '@/lib/wheel'

interface Props {
  data: ProjectionPoint[]
  yKey: keyof ProjectionPoint
  xKey: keyof ProjectionPoint
  color: string
  formatY?: (v: number) => string
}

export default function MiniChart({ data, yKey, xKey, color, formatY }: Props) {
  if (!data || data.length < 2) return null
  const W = 560, H = 180
  const pad = { top: 16, right: 16, bottom: 36, left: 64 }
  const iW = W - pad.left - pad.right
  const iH = H - pad.top - pad.bottom

  const xs = data.map(d => d[xKey] as number)
  const ys = data.map(d => d[yKey] as number)
  const minX = xs[0], maxX = xs[xs.length - 1]
  const minY = 0, maxY = Math.max(...ys) * 1.1

  const px = (x: number) => pad.left + ((x - minX) / (maxX - minX || 1)) * iW
  const py = (y: number) => pad.top + iH - ((y - minY) / (maxY - minY || 1)) * iH

  const pts = data.map(d => `${px(d[xKey] as number)},${py(d[yKey] as number)}`).join(' ')
  const area = `${px(minX)},${py(0)} ${pts} ${px(maxX)},${py(0)}`

  const yTicks = [0, 0.25, 0.5, 0.75, 1].map(t => minY + (maxY - minY) * t)
  const xTicks = data.filter((_, i) => i % Math.floor(data.length / 5) === 0)

  const gradId = `g-${String(yKey)}`

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: '100%', height: 'auto' }}>
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" />
          <stop offset="100%" stopColor={color} stopOpacity="0.01" />
        </linearGradient>
      </defs>
      {yTicks.map((v, i) => (
        <g key={i}>
          <line x1={pad.left} y1={py(v)} x2={W - pad.right} y2={py(v)} stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
          <text x={pad.left - 8} y={py(v) + 4} textAnchor="end" fill="rgba(255,255,255,0.35)" fontSize="10" fontFamily="sans-serif">
            {formatY ? formatY(v) : Math.round(v).toLocaleString()}
          </text>
        </g>
      ))}
      {xTicks.map((d, i) => (
        <text key={i} x={px(d[xKey] as number)} y={H - 6} textAnchor="middle" fill="rgba(255,255,255,0.35)" fontSize="10" fontFamily="sans-serif">
          Mo {d[xKey]}
        </text>
      ))}
      <polygon points={area} fill={`url(#${gradId})`} />
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" />
      <circle cx={px(maxX)} cy={py(ys[ys.length - 1])} r="4" fill={color} />
    </svg>
  )
}
