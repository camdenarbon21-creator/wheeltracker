'use client'
import { WheelState, derivedStats } from '@/lib/wheel'

interface Props { state: WheelState }

export default function Dashboard({ state }: Props) {
  const s = derivedStats(state)
  const phases = [100, 200, 300, 400, 500, 600]

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* Hero position card */}
      <div style={{ background: 'linear-gradient(135deg, #0a1f14 0%, #091525 100%)', border: '1px solid rgba(0,255,135,0.2)', borderRadius: 20, padding: 24 }}>
        <div style={{ fontSize: 10, color: 'rgba(0,255,135,0.7)', letterSpacing: 1.2, fontWeight: 700, marginBottom: 18 }}>YOUR POSITION</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16, marginBottom: 20 }}>
          {[
            { label: 'TOTAL SHARES', value: s.totalShares.toFixed(1), color: '#fff' },
            { label: 'BLENDED AVG', value: `$${s.avgCost.toFixed(2)}`, color: '#00ff87' },
            { label: 'WEEKLY INCOME', value: `$${s.weeklyPremium}`, color: '#60efff' },
          ].map((item, i) => (
            <div key={i}>
              <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, marginBottom: 5 }}>{item.label}</div>
              <div style={{ fontSize: 22, fontWeight: 900, color: item.color, lineHeight: 1 }}>{item.value}</div>
            </div>
          ))}
        </div>

        {/* Bought vs Premium */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div style={{ background: 'rgba(255,255,255,0.06)', borderRadius: 12, padding: '12px 14px' }}>
            <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, marginBottom: 6 }}>💵 PURCHASED</div>
            <div style={{ fontSize: 20, fontWeight: 800 }}>{s.boughtShares.toFixed(1)}</div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 3 }}>avg <span style={{ color: '#fff', fontWeight: 700 }}>${s.boughtAvg.toFixed(2)}</span></div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)', marginTop: 1 }}>${s.boughtCost.toFixed(0)} deployed</div>
          </div>
          <div style={{ background: 'rgba(0,255,135,0.07)', border: '1px solid rgba(0,255,135,0.15)', borderRadius: 12, padding: '12px 14px' }}>
            <div style={{ fontSize: 9, color: 'rgba(0,255,135,0.7)', letterSpacing: 1, marginBottom: 6 }}>🔄 FROM PREMIUM</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: '#00ff87' }}>{s.premiumShares.toFixed(1)}</div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', marginTop: 3 }}>avg <span style={{ color: '#00ff87', fontWeight: 700 }}>{s.premiumShares > 0 ? `$${s.premiumAvg.toFixed(2)}` : '—'}</span></div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)', marginTop: 1 }}>{s.premiumShares > 0 ? `$${s.premiumCost.toFixed(0)} cost` : 'add premium lots'}</div>
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
        {[
          { label: 'CONTRACTS', value: `${s.contracts}`, sub: `${s.contracts * 100} shares` },
          { label: 'ANNUAL INCOME', value: s.annualPremium >= 1000 ? `$${(s.annualPremium/1000).toFixed(1)}K` : `$${s.annualPremium}`, sub: 'at current pace' },
          { label: 'YIELD ON COST', value: `${s.yieldOnCost.toFixed(1)}%`, sub: 'annual premium/cost' },
        ].map((item, i) => (
          <div key={i} className="card" style={{ padding: '14px 16px' }}>
            <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, marginBottom: 6 }}>{item.label}</div>
            <div style={{ fontSize: 20, fontWeight: 800 }}>{item.value}</div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.35)', marginTop: 2 }}>{item.sub}</div>
          </div>
        ))}
      </div>

      {/* Market value */}
      <div className="card" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {[
          { label: 'MARKET VALUE', value: `$${Math.round(s.marketValue).toLocaleString()}` },
          { label: 'UNREALIZED P&L', value: `${s.unrealizedPL >= 0 ? '+' : ''}$${Math.round(s.unrealizedPL).toLocaleString()}`, color: s.unrealizedPL >= 0 ? '#00ff87' : '#ff5555', sub: `${s.unrealizedPct >= 0 ? '+' : ''}${s.unrealizedPct.toFixed(1)}%` },
        ].map((item, i) => (
          <div key={i}>
            <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, marginBottom: 5 }}>{item.label}</div>
            <div style={{ fontSize: 18, fontWeight: 800, color: item.color || '#fff' }}>{item.value}</div>
            {item.sub && <div style={{ fontSize: 11, color: item.color || 'rgba(255,255,255,0.4)', marginTop: 2 }}>{item.sub}</div>}
          </div>
        ))}
      </div>

      {/* Progress to 200 */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
          <div style={{ fontSize: 13, fontWeight: 700 }}>Progress to 200 Shares</div>
          <div style={{ fontSize: 13, color: '#00ff87', fontWeight: 700 }}>{s.progressTo200.toFixed(1)}%</div>
        </div>
        <div style={{ background: 'rgba(255,255,255,0.08)', borderRadius: 99, height: 8, overflow: 'hidden', marginBottom: 8 }}>
          <div style={{ width: `${s.progressTo200}%`, height: '100%', background: 'linear-gradient(90deg, #00ff87, #60efff)', borderRadius: 99, transition: 'width 0.6s ease' }} />
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>{s.totalShares.toFixed(1)} / 200 shares</span>
          <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>
            {s.progressTo200 >= 100 ? '🎉 Goal reached!' : s.weeksTo200 ? `~${s.weeksTo200} weeks` : '—'}
          </span>
        </div>
      </div>

      {/* Phase tracker */}
      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, fontWeight: 700, marginBottom: 14 }}>COMPOUNDING PHASES</div>
        {phases.map((target, i) => {
          const reached = s.totalShares >= target
          const active = s.totalShares >= target - 100 && s.totalShares < target
          return (
            <div key={target} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: i < phases.length - 1 ? '1px solid rgba(255,255,255,0.05)' : 'none', opacity: reached || active ? 1 : 0.3 }}>
              <div style={{ width: 30, height: 30, borderRadius: '50%', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, background: reached ? 'linear-gradient(135deg,#00ff87,#00d4ff)' : active ? 'rgba(255,255,255,0.1)' : 'rgba(255,255,255,0.05)', border: active ? '2px solid #00ff87' : '2px solid transparent', color: reached ? '#000' : '#fff', fontWeight: 800 }}>
                {reached ? '✓' : active ? '→' : '○'}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 14 }}>{target} shares</div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>{target / 100} contract{target / 100 > 1 ? 's' : ''} · ${(target / 100 * state.premiumPerContract).toLocaleString()}/wk</div>
              </div>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#00ff87' }}>
                ${((target / 100) * state.premiumPerContract * 52).toLocaleString()}/yr
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
