'use client'
import { WheelState, calcProjection, derivedStats, formatMoney } from '@/lib/wheel'
import MiniChart from './MiniChart'

interface Props { state: WheelState }

export default function TenYear({ state }: Props) {
  const s = derivedStats(state)
  const proj = calcProjection(s.totalShares, state.premiumPerContract, state.currentHoodPrice)

  const bigStats = [
    { label: 'SHARES IN 10 YEARS', value: proj.finalShares.toLocaleString(), color: '#fff' },
    { label: 'WEEKLY PREMIUM YR 10', value: formatMoney(proj.finalWeeklyPremium), color: '#00ff87' },
    { label: 'ANNUAL INCOME YR 10', value: formatMoney(proj.finalWeeklyPremium * 52), color: '#60efff' },
    { label: 'TOTAL PREMIUM EARNED', value: formatMoney(proj.totalPremium), color: '#fff' },
  ]

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {bigStats.map((s, i) => (
          <div key={i} className="card" style={{ padding: '16px 18px' }}>
            <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.35)', letterSpacing: 1, marginBottom: 8 }}>{s.label}</div>
            <div style={{ fontSize: 20, fontWeight: 800, color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, fontWeight: 700, marginBottom: 14 }}>SHARES GROWTH</div>
        <MiniChart data={proj.weeklyData} yKey="shares" xKey="month" color="#00ff87" formatY={v => v >= 1000 ? `${(v/1000).toFixed(1)}K` : Math.round(v).toString()} />
      </div>

      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, fontWeight: 700, marginBottom: 14 }}>WEEKLY PREMIUM INCOME</div>
        <MiniChart data={proj.weeklyData} yKey="weeklyPremium" xKey="month" color="#60efff" formatY={v => v >= 1000 ? `$${(v/1000).toFixed(0)}K` : `$${Math.round(v)}`} />
      </div>

      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, fontWeight: 700, marginBottom: 14 }}>YEAR BY YEAR</div>
        {[1,2,3,4,5,6,7,8,9,10].map(yr => {
          const snap = proj.weeklyData.find(d => d.month >= yr * 12) || proj.weeklyData[proj.weeklyData.length - 1]
          return (
            <div key={yr} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: yr < 10 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}>
              <div style={{ fontWeight: 700, fontSize: 14, color: 'rgba(255,255,255,0.7)', width: 56 }}>Year {yr}</div>
              <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)' }}>{snap ? snap.shares.toLocaleString() : '—'} sh</div>
              <div style={{ fontSize: 13, color: '#00ff87', fontWeight: 700 }}>{snap ? formatMoney(snap.weeklyPremium) : '—'}/wk</div>
              <div style={{ fontSize: 13, color: '#60efff', fontWeight: 700 }}>{snap ? formatMoney(snap.weeklyPremium * 52) : '—'}/yr</div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
