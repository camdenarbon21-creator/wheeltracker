'use client'
import { WheelState, calcProjection, derivedStats, formatMoney } from '@/lib/wheel'

interface Props { state: WheelState }

export default function Milestones({ state }: Props) {
  const s = derivedStats(state)
  const proj = calcProjection(s.totalShares, state.premiumPerContract, state.currentHoodPrice)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(0,255,135,0.7)', letterSpacing: 1.2, fontWeight: 700, marginBottom: 4 }}>MILESTONE PROJECTIONS</div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 16 }}>
          Starting from {s.totalShares.toFixed(0)} shares · ${state.premiumPerContract}/contract/week · HOOD @ ${state.currentHoodPrice}
        </div>
        <div style={{ overflowX: 'auto', WebkitOverflowScrolling: 'touch' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, minWidth: 400 }}>
            <thead>
              <tr>
                {['Shares', 'Month', 'Wkly $', 'Annual $', 'Cumulative $'].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '8px 10px', color: 'rgba(255,255,255,0.35)', fontWeight: 600, fontSize: 10, letterSpacing: 0.5, borderBottom: '1px solid rgba(255,255,255,0.08)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {proj.milestones.map((m, i) => {
                const reached = s.totalShares >= m.shares
                return (
                  <tr key={i} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)', background: reached ? 'rgba(0,255,135,0.04)' : 'transparent' }}>
                    <td style={{ padding: '11px 10px', fontWeight: 800, fontSize: 15, color: reached ? '#00ff87' : '#fff' }}>
                      {reached && <span style={{ fontSize: 11, marginRight: 4 }}>✓</span>}{m.shares}
                    </td>
                    <td style={{ padding: '11px 10px', color: 'rgba(255,255,255,0.6)' }}>Mo {m.month}</td>
                    <td style={{ padding: '11px 10px', color: '#00ff87', fontWeight: 700 }}>${m.weeklyPremium.toLocaleString()}</td>
                    <td style={{ padding: '11px 10px', color: '#60efff', fontWeight: 700 }}>{formatMoney(m.weeklyPremium * 52)}</td>
                    <td style={{ padding: '11px 10px', color: 'rgba(255,255,255,0.5)' }}>{formatMoney(m.totalPremium)}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Phase acceleration explainer */}
      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, fontWeight: 700, marginBottom: 14 }}>WHY IT ACCELERATES</div>
        {[
          { phase: '100 → 200', contracts: 1, wkly: state.premiumPerContract, months: Math.round((100 * state.currentHoodPrice) / state.premiumPerContract / 4.33) },
          { phase: '200 → 300', contracts: 2, wkly: state.premiumPerContract * 2, months: Math.round((100 * state.currentHoodPrice) / (state.premiumPerContract * 2) / 4.33) },
          { phase: '300 → 400', contracts: 3, wkly: state.premiumPerContract * 3, months: Math.round((100 * state.currentHoodPrice) / (state.premiumPerContract * 3) / 4.33) },
          { phase: '400 → 500', contracts: 4, wkly: state.premiumPerContract * 4, months: Math.round((100 * state.currentHoodPrice) / (state.premiumPerContract * 4) / 4.33) },
        ].map((row, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: i < 3 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14 }}>{row.phase} shares</div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>{row.contracts} contract{row.contracts > 1 ? 's' : ''} · ${row.wkly}/wk</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 16, fontWeight: 800, color: '#00ff87' }}>~{row.months} mo</div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)' }}>to add 100 shares</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
