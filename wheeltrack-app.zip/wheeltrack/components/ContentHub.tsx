'use client'
import { useState } from 'react'
import { WheelState, derivedStats } from '@/lib/wheel'

interface Props { state: WheelState }

export default function ContentHub({ state }: Props) {
  const [copied, setCopied] = useState<string | null>(null)
  const s = derivedStats(state)

  const copy = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(key)
      setTimeout(() => setCopied(null), 2000)
    })
  }

  const captions = [
    {
      id: 'update',
      label: '📈 Weekly Update',
      text: `📈 HOOD Wheel Strategy — Week Update\n\n🟢 Total Shares: ${s.totalShares.toFixed(1)}\n💵 Purchased: ${s.boughtShares} shares @ avg $${s.boughtAvg.toFixed(2)}\n🔄 Via Premium: ${s.premiumShares.toFixed(1)} shares @ avg $${s.premiumAvg > 0 ? s.premiumAvg.toFixed(2) : '—'}\n🎯 Blended Avg Cost: $${s.avgCost.toFixed(2)}\n💰 Weekly Income: $${s.weeklyPremium}/week\n📊 Progress to 200 shares: ${s.progressTo200.toFixed(1)}%\n\nFollowing the journey? Drop a 🔥\n\n#HOOD #OptionsTrading #WheelStrategy #Investing`,
    },
    {
      id: 'milestone',
      label: '🎯 Milestone Post',
      text: `Just hit ${Math.floor(s.totalShares / 100) * 100} shares on $HOOD 🔥\n\nStarted with ${state.lots[0]?.shares || 100} shares @ $${state.hoodStartPrice}\nBlended avg cost after premium reinvestment: $${s.avgCost.toFixed(2)}\n\nEvery week I sell a covered call, collect the premium, and buy more shares. The wheel never stops.\n\n${s.premiumShares > 0 ? `${s.premiumShares.toFixed(1)} of my shares cost me nothing — they came from premium.\n\n` : ''}Next milestone: ${Math.ceil(s.totalShares / 100) * 100} shares 👀\n\n#OptionsTrading #WheelStrategy #HOOD #Compounding`,
    },
    {
      id: 'hook',
      label: '🎣 Engagement Hook',
      text: `Most people don't know you can use stocks to pay for more stocks.\n\nI sell covered calls on my $HOOD position every week. The premium I collect goes straight back into more shares.\n\nStarted @ $${state.hoodStartPrice}. My average cost? $${s.avgCost.toFixed(2)}.\n\nThe snowball is real. 🏔️\n\nFollow along 👇\n\n#HOOD #WheelStrategy #OptionsIncome #Investing #FinancialFreedom`,
    },
    {
      id: 'math',
      label: '🔢 The Math Post',
      text: `The HOOD Wheel — by the numbers 📊\n\n${s.contracts} contract${s.contracts !== 1 ? 's' : ''} → $${s.weeklyPremium}/week\n$${s.weeklyPremium}/week → ${(s.weeklyPremium / state.currentHoodPrice).toFixed(1)} new shares added\n${(s.weeklyPremium / state.currentHoodPrice).toFixed(1)} shares/week → 100 new shares every ~${Math.round(100 / (s.weeklyPremium / state.currentHoodPrice))} weeks\n\nOnce I hit 200 shares I run 2 contracts → $${s.weeklyPremium * 2}/week\nThat cuts the next 100 shares in HALF the time.\n\nThis is compounding. This is the point.\n\n#HOOD #OptionsTrading #WheelStrategy #Compounding`,
    },
  ]

  const ideas = [
    { emoji: '📹', title: 'Monday Update Reel', desc: 'Screen record the tracker, talk over the numbers. Post every Monday morning.' },
    { emoji: '🎯', title: 'Milestone Unlock', desc: 'Every 100 shares is a celebration post. Build the hype around each one.' },
    { emoji: '💸', title: 'Cost Basis Reveal', desc: '"Started HOOD at $106. My actual average cost after all premium shares? Watch."' },
    { emoji: '📊', title: 'The 10-Year Chart', desc: 'Post the projection. Caption: "This is what happens if I never stop." Zero followers resist that.' },
    { emoji: '🔴', title: 'Assignment Day', desc: 'If you get called away or assigned, film it. Showing losses is 10x more engaging than wins.' },
    { emoji: '🎓', title: 'Wheel 101', desc: '"Nobody taught me this in school. Here\'s exactly how the options wheel works in 60 seconds."' },
  ]

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(0,255,135,0.7)', letterSpacing: 1.2, fontWeight: 700, marginBottom: 4 }}>CAPTION GENERATOR</div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', marginBottom: 16 }}>Auto-filled with your live numbers. Tap to copy.</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {captions.map(cap => (
            <div key={cap.id}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 6, color: 'rgba(255,255,255,0.7)' }}>{cap.label}</div>
              <div style={{ background: 'rgba(0,0,0,0.4)', borderRadius: 10, padding: 14, fontFamily: 'monospace', fontSize: 12, lineHeight: 1.7, color: 'rgba(255,255,255,0.75)', whiteSpace: 'pre-line', marginBottom: 6 }}>
                {cap.text}
              </div>
              <button onClick={() => copy(cap.text, cap.id)} style={{ background: copied === cap.id ? 'linear-gradient(135deg,#00ff87,#00d4ff)' : 'rgba(255,255,255,0.08)', border: 'none', borderRadius: 8, padding: '8px 16px', color: copied === cap.id ? '#000' : '#fff', fontWeight: 700, fontSize: 12, cursor: 'pointer', transition: 'all 0.2s' }}>
                {copied === cap.id ? '✓ Copied!' : 'Copy Caption'}
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', letterSpacing: 1, fontWeight: 700, marginBottom: 14 }}>SERIES IDEAS</div>
        {ideas.map((idea, i) => (
          <div key={i} style={{ display: 'flex', gap: 14, padding: '12px 0', borderBottom: i < ideas.length - 1 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}>
            <div style={{ fontSize: 22, flexShrink: 0 }}>{idea.emoji}</div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 3 }}>{idea.title}</div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', lineHeight: 1.5 }}>{idea.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
