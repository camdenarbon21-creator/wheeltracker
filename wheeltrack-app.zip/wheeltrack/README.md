# WheelTrack — HOOD Options Wheel Strategy Tracker

A full Next.js PWA for tracking your HOOD covered call wheel strategy in real time.

## Features
- Track every share lot with exact buy price and source (purchased vs premium)
- Real blended average cost basis across all lots
- Milestone projections with realistic compounding math
- 10-year growth charts and year-by-year snapshots
- Auto-generated Instagram captions from your live data
- Saves to device localStorage — no account needed
- Installable as a PWA (Add to Home Screen on iPhone)

## Deploy in 5 Minutes (Vercel)

1. Push this folder to a GitHub repo
2. Go to vercel.com → New Project → Import your repo
3. Zero config needed — Vercel detects Next.js automatically
4. Hit Deploy → your live URL is ready

That URL goes in your Instagram bio.

## Deploy to Netlify

1. Push to GitHub
2. Netlify → New Site → Import from GitHub
3. Build command: `npm run build`
4. Publish directory: `.next`
5. Add environment variable: `NETLIFY_NEXT_PLUGIN_SKIP=true`

## Local Development

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Make it Yours

- `lib/wheel.ts` — change `HOOD_PRICE_DEFAULT` and `PREMIUM_PER_CONTRACT`
- `app/page.tsx` — edit the landing page copy
- `components/ContentHub.tsx` — customize the caption templates
- `public/manifest.json` — update app name and icons

## Adding Real Icons

Replace `/public/icon-192.png` and `/public/icon-512.png` with your own.
Use a tool like https://realfavicongenerator.net to generate all sizes.
