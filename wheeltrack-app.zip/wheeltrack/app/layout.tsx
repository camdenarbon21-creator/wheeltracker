import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'WheelTrack — HOOD Options Wheel Tracker',
  description: 'Track your HOOD covered call wheel strategy. Watch your shares snowball from premium reinvestment.',
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'WheelTrack',
  },
  openGraph: {
    title: 'WheelTrack — HOOD Wheel Strategy',
    description: 'Watch a scratch golfer turn $10K into a premium-generating machine using the options wheel.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#080b10',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="apple-touch-icon" href="/icon-192.png" />
      </head>
      <body>{children}</body>
    </html>
  )
}
