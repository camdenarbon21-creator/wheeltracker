import Link from 'next/link'

export default function Landing() {
  return (
    <div style={{ background: '#080b10', minHeight: '100vh', color: '#fff', fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", sans-serif' }}>
      {/* Nav */}
      <nav style={{ maxWidth: 700, margin: '0 auto', padding: '20px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontSize: 18, fontWeight: 900, background: 'linear-gradient(90deg,#fff,rgba(0,255,135,0.8))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>WheelTrack</div>
        <Link href="/tracker" style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 10, padding: '8px 18px', color: '#fff', textDecoration: 'none', fontWeight: 600, fontSize: 13 }}>
          Open Tracker →
        </Link>
      </nav>

      {/* Hero */}
      <div style={{ maxWidth: 700, margin: '0 auto', padding: '60px 24px 40px', textAlign: 'center' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'rgba(0,255,135,0.1)', border: '1px solid rgba(0,255,135,0.2)', borderRadius: 99, padding: '5px 14px', fontSize: 11, color: '#00ff87', fontWeight: 700, letterSpacing: 1, marginBottom: 28 }}>
          🔄 OPTIONS WHEEL STRATEGY
        </div>
        <h1 style={{ fontSize: 'clamp(36px, 8vw, 60px)', fontWeight: 900, lineHeight: 1.05, marginBottom: 20, background: 'linear-gradient(160deg, #fff 40%, rgba(0,255,135,0.7) 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
          Watch the snowball<br />build in real time.
        </h1>
        <p style={{ fontSize: 17, color: 'rgba(255,255,255,0.5)', lineHeight: 1.7, maxWidth: 480, margin: '0 auto 40px' }}>
          Tracking a live HOOD wheel strategy — selling covered calls weekly, reinvesting every dollar of premium into more shares. Follow every lot, every week, every milestone.
        </p>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
          <Link href="/tracker" style={{ background: 'linear-gradient(135deg,#00ff87,#00d4ff)', borderRadius: 14, padding: '15px 32px', color: '#000', textDecoration: 'none', fontWeight: 800, fontSize: 16 }}>
            Open the Tracker
          </Link>
          <a href="#how" style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 14, padding: '15px 32px', color: '#fff', textDecoration: 'none', fontWeight: 600, fontSize: 16 }}>
            How it works
          </a>
        </div>
      </div>

      {/* Live preview stats */}
      <div style={{ maxWidth: 700, margin: '0 auto', padding: '0 24px 60px' }}>
        <div style={{ background: 'linear-gradient(135deg, #0a1f14, #091525)', border: '1px solid rgba(0,255,135,0.15)', borderRadius: 20, padding: '28px 28px' }}>
          <div style={{ fontSize: 10, color: 'rgba(0,255,135,0.6)', letterSpacing: 1.2, fontWeight: 700, marginBottom: 20 }}>LIVE POSITION SNAPSHOT</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, marginBottom: 20 }}>
            {[
              { label: 'Started with', value: '100', unit: 'shares' },
              { label: 'Target', value: '200', unit: 'shares' },
              { label: 'Weekly income', value: '$200', unit: 'per contract' },
            ].map((s, i) => (
              <div key={i} style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 28, fontWeight: 900, color: i === 2 ? '#00ff87' : '#fff' }}>{s.value}</div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.35)', marginTop: 2 }}>{s.label}</div>
                <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.2)' }}>{s.unit}</div>
              </div>
            ))}
          </div>
          <div style={{ height: 1, background: 'rgba(255,255,255,0.06)', marginBottom: 20 }} />
          <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)', lineHeight: 1.6, textAlign: 'center' }}>
            Every week: sell 1 covered call → collect ~$200 premium → buy ~1.9 more HOOD shares.<br />
            <span style={{ color: 'rgba(0,255,135,0.7)' }}>At 200 shares: 2 contracts → $400/wk. The pace doubles. It keeps going.</span>
          </div>
        </div>
      </div>

      {/* How it works */}
      <div id="how" style={{ maxWidth: 700, margin: '0 auto', padding: '0 24px 80px' }}>
        <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)', letterSpacing: 1.2, fontWeight: 700, textAlign: 'center', marginBottom: 8 }}>THE STRATEGY</div>
        <h2 style={{ fontSize: 28, fontWeight: 900, textAlign: 'center', marginBottom: 40 }}>How the wheel works</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {[
            { n: '01', title: 'Own 100 shares of HOOD', desc: 'You need at least 100 shares to sell one covered call contract. That\'s the starting block.' },
            { n: '02', title: 'Sell a covered call weekly', desc: 'Pick a strike price above the current price. Collect ~$200 in premium instantly. The buyer pays you for the right to buy your shares.' },
            { n: '03', title: 'Reinvest 100% of premium', desc: 'Every dollar collected goes straight back into more HOOD shares. At $106/share, $200 buys ~1.9 shares per week.' },
            { n: '04', title: 'Watch contracts compound', desc: 'At 200 shares you run 2 contracts → $400/week. At 300 shares, 3 contracts → $600/week. Each milestone accelerates the next.' },
          ].map((step, i) => (
            <div key={i} style={{ display: 'flex', gap: 16, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 16, padding: '20px 20px' }}>
              <div style={{ fontSize: 11, fontWeight: 800, color: 'rgba(0,255,135,0.5)', letterSpacing: 1, flexShrink: 0, marginTop: 3 }}>{step.n}</div>
              <div>
                <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 5 }}>{step.title}</div>
                <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)', lineHeight: 1.6 }}>{step.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div style={{ textAlign: 'center', padding: '0 24px 80px' }}>
        <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.35)', marginBottom: 20 }}>Your data saves to your device. Nothing leaves your browser.</p>
        <Link href="/tracker" style={{ background: 'linear-gradient(135deg,#00ff87,#00d4ff)', borderRadius: 14, padding: '15px 40px', color: '#000', textDecoration: 'none', fontWeight: 800, fontSize: 16, display: 'inline-block' }}>
          Start Tracking →
        </Link>
      </div>
    </div>
  )
}
