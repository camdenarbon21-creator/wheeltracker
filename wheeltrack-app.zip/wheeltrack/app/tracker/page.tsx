'use client'
import { useState, useEffect } from 'react'
import { WheelState } from '@/lib/wheel'
import { loadState, saveState } from '@/lib/storage'
import Dashboard from '@/components/Dashboard'
import Positions from '@/components/Positions'
import Milestones from '@/components/Milestones'
import TenYear from '@/components/TenYear'
import ContentHub from '@/components/ContentHub'

const TABS = [
  { id: 'dashboard', label: '📊 Dashboard' },
  { id: 'positions', label: '📦 Positions' },
  { id: 'milestones', label: '🎯 Milestones' },
  { id: 'tenyear', label: '📈 10-Year' },
  { id: 'content', label: '📱 Content' },
]

export default function TrackerPage() {
  const [state, setState] = useState<WheelState | null>(null)
  const [tab, setTab] = useState('dashboard')

  useEffect(() => { setState(loadState()) }, [])

  const handleChange = (newState: WheelState) => {
    setState(newState)
    saveState(newState)
  }

  if (!state) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#080b10' }}>
      <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>Loading...</div>
    </div>
  )

  return (
    <div style={{ background: '#080b10', minHeight: '100vh' }}>
      <div style={{ background: 'linear-gradient(180deg, #0d1117 0%, #080b10 100%)', borderBottom: '1px solid rgba(255,255,255,0.06)', position: 'sticky', top: 0, zIndex: 100 }}>
        <div style={{ maxWidth: 680, margin: '0 auto', padding: '16px 20px 0' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ background: 'linear-gradient(135deg,#00ff87,#60efff)', borderRadius: 6, padding: '3px 8px', fontSize: 10, fontWeight: 800, color: '#000', letterSpacing: 1 }}>LIVE</div>
                <span style={{ color: 'rgba(255,255,255,0.35)', fontSize: 12 }}>HOOD Options Wheel</span>
              </div>
              <div style={{ fontSize: 20, fontWeight: 900, marginTop: 2, background: 'linear-gradient(90deg,#fff 50%,rgba(0,255,135,0.6))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                WheelTrack
              </div>
            </div>
            <a href="/" style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)', textDecoration: 'none' }}>← Home</a>
          </div>
          <div style={{ display: 'flex', gap: 0, overflowX: 'auto', WebkitOverflowScrolling: 'touch', scrollbarWidth: 'none' }}>
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{ background: 'none', border: 'none', borderBottom: tab === t.id ? '2px solid #00ff87' : '2px solid transparent', color: tab === t.id ? '#00ff87' : 'rgba(255,255,255,0.4)', fontWeight: tab === t.id ? 700 : 400, fontSize: 12, padding: '6px 14px', cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0 }}>
                {t.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 680, margin: '0 auto', padding: '20px 16px 80px' }}>
        {tab === 'dashboard' && <Dashboard state={state} />}
        {tab === 'positions' && <Positions state={state} onChange={handleChange} />}
        {tab === 'milestones' && <Milestones state={state} />}
        {tab === 'tenyear' && <TenYear state={state} />}
        {tab === 'content' && <ContentHub state={state} />}
      </div>
    </div>
  )
}
